#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

typedef struct TreeNode {
	int data;
	struct TreeNode* left, * right;
} TreeNode;

TreeNode n1 = { 'a', NULL, NULL};
TreeNode n2 = { 'b', NULL, NULL};
TreeNode n3 = { 'c', NULL, NULL};
TreeNode n4 = { 'd', NULL, NULL};
TreeNode n5 = { '*', &n1,  &n2 };
TreeNode n6 = { '+', &n3,  &n4 };
TreeNode n7 = { '/', &n5,  &n6 };
TreeNode* root = &n7;

void inorder(TreeNode* root) {
	if (root != NULL) {
		inorder(root->left);
		printf("%c ", root->data);
		inorder(root->right);
	}
}

void preorder(TreeNode* root) {
	if (root != NULL) {
		printf("%c ", root->data);
		preorder(root->left);
		preorder(root->right);
	}
}

void postorder(TreeNode* root) {
	if (root != NULL) {
		postorder(root->left);
		postorder(root->right);
		printf("%c ", root->data);
	}
}

int main()
{
	printf("���� ��ȸ= ");
	inorder(root);
	printf("\n");

	printf("���� ��ȸ= ");
	preorder(root);
	printf("\n");

	printf("���� ��ȸ= ");
	postorder(root);
	printf("\n");
	return 0;
}