#include <stdio.h>

typedef struct TreeNode {
	int key;
	struct TreeNode* left, * right;
} TreeNode;

TreeNode* search(TreeNode* node, int key)
{
	while (node != NULL) {
		if (key == node->key) return node;
		else if (key < node->key)
			node = node->left;
		else
			node = node->right;
	}
	return NULL;

}


int main() {
	TreeNode n1 = { 10,  NULL, NULL};
	TreeNode n2 = { 20,  NULL,  NULL};
	TreeNode n3 = { 30,  &n1,  &n2,};
	TreeNode n4 = { 40, NULL, NULL,};
	TreeNode n5 = { 50, NULL, NULL,};
	TreeNode n6 = { 60, &n4,  &n5};
	TreeNode n7 = { 70, &n3,  &n6};
	TreeNode* exp = &n7;
	int key;

	key = 10;
	if (search(exp,key))
		printf("key : %d Ž�� ����\n", key);
	else
		printf("key : %d Ž�� ����\n", key);

	key = 80;
	if (search(exp, key))
		printf("key : %d Ž�� ����\n",key);
	else
		printf("key : %d Ž�� ����\n", key);
	return 0;
}

